var class_move =
[
    [ "setActivated", "class_move.html#af0326636647d755368aa657a5cf97cbe", null ],
    [ "myTransform", "class_move.html#a37d9e5e6fba0c218526752d9cca34a3a", null ],
    [ "speed", "class_move.html#ad3bff9bc14f0e22d33fe5b5b5d9b58b1", null ]
];
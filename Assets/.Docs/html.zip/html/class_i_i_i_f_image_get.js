var class_i_i_i_f_image_get =
[
    [ "changeAddress", "class_i_i_i_f_image_get.html#ae312ad6a713e6d7cee3210db59838f00", null ],
    [ "getAddress", "class_i_i_i_f_image_get.html#af37d0e78a9db92c63e1f04e3589f05b1", null ],
    [ "GetProgress", "class_i_i_i_f_image_get.html#af36dc447c2e08becce3eb0946b7372ec", null ],
    [ "removeTail", "class_i_i_i_f_image_get.html#aabc551661bd940d1a06c99074d3cd759", null ],
    [ "UpdateImage", "class_i_i_i_f_image_get.html#a2f44ae11571a424cb7e6b473036577a3", null ],
    [ "cropHeight", "class_i_i_i_f_image_get.html#a9db467afe54453d71953d79d09ccd856", null ],
    [ "cropOffsetX", "class_i_i_i_f_image_get.html#a3e424fce3d74529b87b488a4a918da64", null ],
    [ "cropOffsetY", "class_i_i_i_f_image_get.html#ab21f44619cba32ab34a99723f4e2c21e", null ],
    [ "cropWidth", "class_i_i_i_f_image_get.html#ab88ed28d3c28596fbd0f61ed53551bba", null ],
    [ "format", "class_i_i_i_f_image_get.html#a816a7c3831777caa0bf2c314dc9e3d2b", null ],
    [ "mirrored", "class_i_i_i_f_image_get.html#a8ca420b349df804f1dd087cfdaa389e4", null ],
    [ "quality", "class_i_i_i_f_image_get.html#a0edb84f6ed8c3618bfbcb5383403f756", null ],
    [ "rotation", "class_i_i_i_f_image_get.html#a4cdbf0a334d0be4334c00a2cb6eb26c1", null ],
    [ "targetHeight", "class_i_i_i_f_image_get.html#a81ec0146df6843169c7a301d0018b29b", null ],
    [ "targetWidth", "class_i_i_i_f_image_get.html#ad29efbe7f08cd76fa519aa5ca036c404", null ],
    [ "texture", "class_i_i_i_f_image_get.html#acd964c8562547558f31bfc04ff434565", null ],
    [ "webAddress", "class_i_i_i_f_image_get.html#a4b3539da1bc9765bae28166cbe13bdfb", null ]
];
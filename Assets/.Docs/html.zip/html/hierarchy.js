var hierarchy =
[
    [ "Annotation.AnnotationBox", "struct_annotation_1_1_annotation_box.html", null ],
    [ "AssemblyCSharp.IIIFGetManifest", "class_assembly_c_sharp_1_1_i_i_i_f_get_manifest.html", null ],
    [ "MonoBehaviour", null, [
      [ "Annotation", "class_annotation.html", null ],
      [ "AnnotationDrawer", "class_annotation_drawer.html", null ],
      [ "AnnotationUI", "class_annotation_u_i.html", null ],
      [ "BookHandler", "class_book_handler.html", null ],
      [ "ButtonControls", "class_button_controls.html", null ],
      [ "CameraSwitch", "class_camera_switch.html", null ],
      [ "DialogBox", "class_dialog_box.html", null ],
      [ "HandOnPage", "class_hand_on_page.html", null ],
      [ "IIIFImageGet", "class_i_i_i_f_image_get.html", null ],
      [ "IIIFImageLoadingBar", "class_i_i_i_f_image_loading_bar.html", null ],
      [ "Move", "class_move.html", null ],
      [ "MovePlayer", "class_move_player.html", null ],
      [ "MoveSpotlight", "class_move_spotlight.html", null ],
      [ "MoveTranscriptionLens", "class_move_transcription_lens.html", null ],
      [ "PageImages", "class_page_images.html", null ],
      [ "PopUpBox", "class_pop_up_box.html", null ],
      [ "TranscriptionTool", "class_transcription_tool.html", null ],
      [ "UIPopUp", "class_u_i_pop_up.html", null ]
    ] ]
];
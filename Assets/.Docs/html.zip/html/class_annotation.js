var class_annotation =
[
    [ "AnnotationBox", "struct_annotation_1_1_annotation_box.html", "struct_annotation_1_1_annotation_box" ],
    [ "GetAnnotations", "class_annotation.html#a6f51b2747ec2eae72f61bd83fd9d47a7", null ],
    [ "LocalAnnotationFile", "class_annotation.html#ad60e0259e6a6a490d7e2e250e7a121a6", null ],
    [ "UpdateWebAddress", "class_annotation.html#aec2adf7ea1bf592d75c43133df56d33d", null ],
    [ "bottomRight", "class_annotation.html#a784e68c2876b721c7332ad8c4d19d4b4", null ],
    [ "page", "class_annotation.html#a89356eeb4c128231a7542016d61fe35c", null ],
    [ "pageHeight", "class_annotation.html#a6ed1263c99626c3db9c3af44d7853761", null ],
    [ "pageWidth", "class_annotation.html#a3eeea869dfc405c3ed8b3556cf4181b7", null ],
    [ "topLeft", "class_annotation.html#a6701449aed12538b4be40a9d2f1a9898", null ],
    [ "webAddress", "class_annotation.html#adb6d8fefb4974f1ff1d0f0a031455f37", null ],
    [ "webdata", "class_annotation.html#a349cea2640123c51730779a08eaaf8e1", null ]
];
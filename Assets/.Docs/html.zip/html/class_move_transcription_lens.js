var class_move_transcription_lens =
[
    [ "lensImg", "class_move_transcription_lens.html#a5866efc3b483fb9ffe6143687db88718", null ],
    [ "maskImg", "class_move_transcription_lens.html#aa6cfdf5315d72486178bc311132e8363", null ]
];
var class_dialog_box =
[
    [ "OnOkay", "class_dialog_box.html#aa639f926939b142fda80df1df7dd8099", null ],
    [ "Show", "class_dialog_box.html#ae7bb70f489704a901fb2de4115501c59", null ],
    [ "myText", "class_dialog_box.html#ab844ea3cf0c1fb85617853ce9d8161ef", null ]
];
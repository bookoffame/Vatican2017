var class_pop_up_box =
[
    [ "Cancel", "class_pop_up_box.html#af40a3029d3e07286c29b859181072ee8", null ],
    [ "getText", "class_pop_up_box.html#ac80e75be1581aeacb6727bac277b5e1c", null ],
    [ "PopUp", "class_pop_up_box.html#a29566d075e78858a091f201798e49555", null ],
    [ "reset", "class_pop_up_box.html#acc42337540e97fd45d2f5e6ed8451a4c", null ],
    [ "Submit", "class_pop_up_box.html#abdc32668e20f43015bc213473fb9412a", null ],
    [ "input", "class_pop_up_box.html#a9012f3c4ec923daa534d57d011d2a0ef", null ]
];
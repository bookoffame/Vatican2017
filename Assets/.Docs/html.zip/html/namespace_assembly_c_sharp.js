var namespace_assembly_c_sharp =
[
    [ "IIIFGetManifest", "class_assembly_c_sharp_1_1_i_i_i_f_get_manifest.html", "class_assembly_c_sharp_1_1_i_i_i_f_get_manifest" ]
];
var class_camera_switch =
[
    [ "book", "class_camera_switch.html#a4bb33fead2f75f066977849be4f0759b", null ],
    [ "bookCam", "class_camera_switch.html#a6d303d4cb4dd6983e12c3e26417efeca", null ],
    [ "canvas", "class_camera_switch.html#a5877253af2d76ac5a6c02c8509fd3a73", null ],
    [ "fpc", "class_camera_switch.html#a29f086892b51afb2bf09849fd70b6e9b", null ],
    [ "player", "class_camera_switch.html#aef916b4104b8334d1fa50e040f096356", null ],
    [ "playerCam", "class_camera_switch.html#a83af59315c7f4a960ccd0cc618403072", null ]
];
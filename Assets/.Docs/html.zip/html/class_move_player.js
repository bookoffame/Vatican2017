var class_move_player =
[
    [ "ChangeControl", "class_move_player.html#abd1c84d23f1a93c79e26f9cf6e495aa8", null ],
    [ "inControl", "class_move_player.html#affaf4ad002a1a2595f8517c92bdb5db7", null ],
    [ "moveScript", "class_move_player.html#ab4f118400fc2b5b9efe4eafe76f62182", null ]
];
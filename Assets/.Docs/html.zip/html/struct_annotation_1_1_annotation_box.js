var struct_annotation_1_1_annotation_box =
[
    [ "contents", "struct_annotation_1_1_annotation_box.html#a34dbf8361a6e99dec24a2e34f2235a47", null ],
    [ "h", "struct_annotation_1_1_annotation_box.html#ae1b9fc84cb44650938afc0622f2a73d7", null ],
    [ "w", "struct_annotation_1_1_annotation_box.html#a8351fba84fd574b466abdc8922444524", null ],
    [ "x", "struct_annotation_1_1_annotation_box.html#a6e431b3be4693eec2a05836305c951b7", null ],
    [ "y", "struct_annotation_1_1_annotation_box.html#abe016787ca879c554211b47dfc6b7965", null ]
];
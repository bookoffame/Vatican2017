var class_annotation_drawer =
[
    [ "ShowAnnotations", "class_annotation_drawer.html#ac123d95b60addde272d0b946dba7ba75", null ],
    [ "UpdatesAnnotations", "class_annotation_drawer.html#a58b5001b2b927121bd9faf0036105590", null ],
    [ "annoObj", "class_annotation_drawer.html#a65eb569e2f2251ae40599541cac14a81", null ],
    [ "bottomRight", "class_annotation_drawer.html#a5cedf015a42cc5bef94c956344217e88", null ],
    [ "canvas", "class_annotation_drawer.html#a82fe9da03536f06847e78186e0c175a1", null ],
    [ "topLeft", "class_annotation_drawer.html#a932f3cf8744289386ec6950d41638f30", null ]
];
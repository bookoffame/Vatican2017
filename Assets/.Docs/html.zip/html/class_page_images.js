var class_page_images =
[
    [ "GetAnnotations", "class_page_images.html#af563e42dd7774f6ea7a51a9e5668ddc0", null ],
    [ "IsLoadingLeft", "class_page_images.html#a5412e1d64104e009ad3cf9fa3c3351dd", null ],
    [ "IsLoadingRight", "class_page_images.html#a7fcf05646abee094ae39cdf725489414", null ],
    [ "ShowAnnotations", "class_page_images.html#aaaebf078a3aaff99a47b5ddbdbbd9dd7", null ],
    [ "TurnPageLeft", "class_page_images.html#a2d94ed5b60c041dd4550f4dfbca0ef94", null ],
    [ "TurnPageRight", "class_page_images.html#a290f753eca727781c135ce41e6fcd48a", null ],
    [ "UpdateAnnotations", "class_page_images.html#ad9678501582f1cb45563e2b294d97ced", null ],
    [ "annotation", "class_page_images.html#a6579d6330bcfb9f7b7782c84f39e8431", null ],
    [ "drawers", "class_page_images.html#a5113b509fe82ac0eb3670856860fa113", null ],
    [ "iiifImage", "class_page_images.html#ac5c26cd4b70e28c0c13f18d6a0cc5b71", null ],
    [ "leftTrans", "class_page_images.html#a640a7d43b34e9f47a2ade8c83c239c78", null ],
    [ "loadingTexture", "class_page_images.html#a23ff461069def11e8c328474c28a6516", null ],
    [ "manifestURL", "class_page_images.html#a4392dd9e57f3dc4f97a90c9deea5fa50", null ],
    [ "pageDisplay", "class_page_images.html#ae0dfe0e7e9f87ff9f0724cfdf856eea0", null ],
    [ "pages", "class_page_images.html#ab33e023afe9968299aee2c600a9b6670", null ],
    [ "rightTrans", "class_page_images.html#a43dd571101b0554c29a48c8fab263042", null ]
];
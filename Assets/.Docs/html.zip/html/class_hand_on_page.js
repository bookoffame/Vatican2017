var class_hand_on_page =
[
    [ "animator", "class_hand_on_page.html#afd57c043c682cf1a01b36c958db9ed18", null ],
    [ "isRight", "class_hand_on_page.html#aeceb11ff110761c6b8de17f6e3db949a", null ],
    [ "others", "class_hand_on_page.html#a8bf4890b1cca8d94dba8b1e1ab3954e6", null ],
    [ "page", "class_hand_on_page.html#a03b366b79c9b970430e0318dd04f98e0", null ],
    [ "pageImages", "class_hand_on_page.html#a700380202f1cfd8554dfa85f918e16e8", null ],
    [ "pageWidth", "class_hand_on_page.html#a83cc71512d2e86c90822af22ce14943d", null ]
];
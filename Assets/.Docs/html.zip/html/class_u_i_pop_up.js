var class_u_i_pop_up =
[
    [ "IsShowing", "class_u_i_pop_up.html#a71354e6d0c5b79a2af374164a3e07036", null ],
    [ "hideAbove", "class_u_i_pop_up.html#a08dd327672fa2988751468c64624b49c", null ],
    [ "hideY", "class_u_i_pop_up.html#af348533bd87896b58b9b71a63cbbddba", null ],
    [ "pos", "class_u_i_pop_up.html#afd353b97181fa8fbad1222f0af69d1d2", null ],
    [ "showY", "class_u_i_pop_up.html#a4bd553bffe09e1bcf5c08f1bc30d7ea0", null ],
    [ "triggerPos", "class_u_i_pop_up.html#adfe9128f5953b521ac2730d8092eb66d", null ]
];
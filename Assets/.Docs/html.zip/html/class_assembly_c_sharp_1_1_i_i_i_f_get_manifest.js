var class_assembly_c_sharp_1_1_i_i_i_f_get_manifest =
[
    [ "IIIFGetManifest", "class_assembly_c_sharp_1_1_i_i_i_f_get_manifest.html#a30a6cafc6b174ee96c1e07310e3e3ba5", null ],
    [ "download", "class_assembly_c_sharp_1_1_i_i_i_f_get_manifest.html#adec3122dc016bb1a71088a1f3ed5a760", null ],
    [ "getNumOfPages", "class_assembly_c_sharp_1_1_i_i_i_f_get_manifest.html#a36f4b3870d7e913b9181b97b2e384707", null ],
    [ "getPage", "class_assembly_c_sharp_1_1_i_i_i_f_get_manifest.html#a363267d41e370600e961c276a620eb31", null ]
];
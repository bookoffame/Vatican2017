var annotated_dup =
[
    [ "AssemblyCSharp", "namespace_assembly_c_sharp.html", "namespace_assembly_c_sharp" ],
    [ "Annotation", "class_annotation.html", "class_annotation" ],
    [ "AnnotationDrawer", "class_annotation_drawer.html", "class_annotation_drawer" ],
    [ "AnnotationUI", "class_annotation_u_i.html", null ],
    [ "BookHandler", "class_book_handler.html", "class_book_handler" ],
    [ "ButtonControls", "class_button_controls.html", "class_button_controls" ],
    [ "CameraSwitch", "class_camera_switch.html", "class_camera_switch" ],
    [ "DialogBox", "class_dialog_box.html", "class_dialog_box" ],
    [ "HandOnPage", "class_hand_on_page.html", "class_hand_on_page" ],
    [ "IIIFImageGet", "class_i_i_i_f_image_get.html", "class_i_i_i_f_image_get" ],
    [ "IIIFImageLoadingBar", "class_i_i_i_f_image_loading_bar.html", "class_i_i_i_f_image_loading_bar" ],
    [ "Move", "class_move.html", "class_move" ],
    [ "MovePlayer", "class_move_player.html", "class_move_player" ],
    [ "MoveSpotlight", "class_move_spotlight.html", "class_move_spotlight" ],
    [ "MoveTranscriptionLens", "class_move_transcription_lens.html", "class_move_transcription_lens" ],
    [ "PageImages", "class_page_images.html", "class_page_images" ],
    [ "PopUpBox", "class_pop_up_box.html", "class_pop_up_box" ],
    [ "TranscriptionTool", "class_transcription_tool.html", "class_transcription_tool" ],
    [ "UIPopUp", "class_u_i_pop_up.html", "class_u_i_pop_up" ]
];
var class_transcription_tool =
[
    [ "UpdatesTranscriptions", "class_transcription_tool.html#a524c1bac32c7492e41bf7d36678da8ca", null ],
    [ "annotations", "class_transcription_tool.html#a0f13c7a0e9de49ce6d51c1d7e27cab17", null ],
    [ "bottomRight", "class_transcription_tool.html#a7fc3f48e81e40135739550028b5ee63b", null ],
    [ "canvas", "class_transcription_tool.html#a1a5a59f37fde0ed8d52fa2af9d7a3561", null ],
    [ "topLeft", "class_transcription_tool.html#ac5ef003ae5d7745a53d8ee5fbb3ffda2", null ]
];
var class_book_handler =
[
    [ "animator", "class_book_handler.html#aee55e4d0b6978567f3b9fe7ced515631", null ],
    [ "models", "class_book_handler.html#a3e0579bd892b63ba3fad5b7284df1774", null ],
    [ "myUI", "class_book_handler.html#aafcf17dc285ab162e349fe84b1ba119b", null ],
    [ "pages", "class_book_handler.html#ac559d4edb6409bd60793a9e94e02f67a", null ]
];
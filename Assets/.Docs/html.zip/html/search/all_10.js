var searchData=
[
  ['uipopup',['UIPopUp',['../class_u_i_pop_up.html',1,'']]],
  ['updateannotations',['UpdateAnnotations',['../class_page_images.html#ad9678501582f1cb45563e2b294d97ced',1,'PageImages']]],
  ['updatebrightness',['updateBrightness',['../class_move_spotlight.html#a52ac982a0b20d11ab96e1c264f40b437',1,'MoveSpotlight']]],
  ['updatehue',['updateHue',['../class_move_spotlight.html#a42e2980f29dbb07819cf8bda8695095b',1,'MoveSpotlight']]],
  ['updateimage',['UpdateImage',['../class_i_i_i_f_image_get.html#a2f44ae11571a424cb7e6b473036577a3',1,'IIIFImageGet']]],
  ['updatesannotations',['UpdatesAnnotations',['../class_annotation_drawer.html#a58b5001b2b927121bd9faf0036105590',1,'AnnotationDrawer']]],
  ['updatesat',['updateSat',['../class_move_spotlight.html#ac1aa13c1e6ab166fc6eac65216f4f4cb',1,'MoveSpotlight']]],
  ['updatesize',['updateSize',['../class_move_spotlight.html#a1a2a859b51a4cc2651127b4ce7f23c69',1,'MoveSpotlight']]],
  ['updatestranscriptions',['UpdatesTranscriptions',['../class_transcription_tool.html#a524c1bac32c7492e41bf7d36678da8ca',1,'TranscriptionTool']]],
  ['updatevalue',['updateValue',['../class_move_spotlight.html#acec837332b344a64454afe71bd08eed9',1,'MoveSpotlight']]],
  ['updatewebaddress',['UpdateWebAddress',['../class_annotation.html#aec2adf7ea1bf592d75c43133df56d33d',1,'Annotation']]]
];

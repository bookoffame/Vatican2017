var searchData=
[
  ['cam',['cam',['../class_move_spotlight.html#a0074ba44a6e80eaf5ff4030bc7bd2199',1,'MoveSpotlight']]],
  ['canvas',['canvas',['../class_annotation_drawer.html#a82fe9da03536f06847e78186e0c175a1',1,'AnnotationDrawer.canvas()'],['../class_camera_switch.html#a5877253af2d76ac5a6c02c8509fd3a73',1,'CameraSwitch.canvas()'],['../class_transcription_tool.html#a1a5a59f37fde0ed8d52fa2af9d7a3561',1,'TranscriptionTool.canvas()']]],
  ['ceilinglight',['ceilingLight',['../class_move_spotlight.html#a0db93502d6482412f36571b5a4b99be7',1,'MoveSpotlight']]],
  ['contents',['contents',['../struct_annotation_1_1_annotation_box.html#a34dbf8361a6e99dec24a2e34f2235a47',1,'Annotation::AnnotationBox']]],
  ['cropheight',['cropHeight',['../class_i_i_i_f_image_get.html#a9db467afe54453d71953d79d09ccd856',1,'IIIFImageGet']]],
  ['cropoffsetx',['cropOffsetX',['../class_i_i_i_f_image_get.html#a3e424fce3d74529b87b488a4a918da64',1,'IIIFImageGet']]],
  ['cropoffsety',['cropOffsetY',['../class_i_i_i_f_image_get.html#ab21f44619cba32ab34a99723f4e2c21e',1,'IIIFImageGet']]],
  ['cropwidth',['cropWidth',['../class_i_i_i_f_image_get.html#ab88ed28d3c28596fbd0f61ed53551bba',1,'IIIFImageGet']]],
  ['current',['current',['../class_button_controls.html#a8104ade53ad756b5a0c70f282b614aa1',1,'ButtonControls']]]
];

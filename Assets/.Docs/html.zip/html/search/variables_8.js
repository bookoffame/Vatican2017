var searchData=
[
  ['manifesturl',['manifestURL',['../class_page_images.html#a4392dd9e57f3dc4f97a90c9deea5fa50',1,'PageImages']]],
  ['maskimg',['maskImg',['../class_move_transcription_lens.html#aa6cfdf5315d72486178bc311132e8363',1,'MoveTranscriptionLens']]],
  ['maxx',['maxX',['../class_move_spotlight.html#affbf3080d9cf95a56d80f1b30b4ee415',1,'MoveSpotlight']]],
  ['maxy',['maxY',['../class_move_spotlight.html#a255c1781f89cb8048d3346d8ed17ee24',1,'MoveSpotlight']]],
  ['minx',['minX',['../class_move_spotlight.html#ab6bdcf35eef7c30ed2f43fe359636c06',1,'MoveSpotlight']]],
  ['miny',['minY',['../class_move_spotlight.html#a791cb5fd988708314ded26cddd7381de',1,'MoveSpotlight']]],
  ['mirrored',['mirrored',['../class_i_i_i_f_image_get.html#a8ca420b349df804f1dd087cfdaa389e4',1,'IIIFImageGet']]],
  ['models',['models',['../class_book_handler.html#a3e0579bd892b63ba3fad5b7284df1774',1,'BookHandler']]],
  ['movescript',['moveScript',['../class_move_player.html#ab4f118400fc2b5b9efe4eafe76f62182',1,'MovePlayer']]],
  ['mytext',['myText',['../class_dialog_box.html#ab844ea3cf0c1fb85617853ce9d8161ef',1,'DialogBox']]],
  ['mytransform',['myTransform',['../class_move.html#a37d9e5e6fba0c218526752d9cca34a3a',1,'Move']]],
  ['myui',['myUI',['../class_book_handler.html#aafcf17dc285ab162e349fe84b1ba119b',1,'BookHandler']]]
];

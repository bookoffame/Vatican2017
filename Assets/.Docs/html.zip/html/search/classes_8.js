var searchData=
[
  ['transcriptiontool',['TranscriptionTool',['../class_transcription_tool.html',1,'']]]
];

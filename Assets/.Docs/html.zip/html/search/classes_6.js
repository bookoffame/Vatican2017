var searchData=
[
  ['move',['Move',['../class_move.html',1,'']]],
  ['moveplayer',['MovePlayer',['../class_move_player.html',1,'']]],
  ['movespotlight',['MoveSpotlight',['../class_move_spotlight.html',1,'']]],
  ['movetranscriptionlens',['MoveTranscriptionLens',['../class_move_transcription_lens.html',1,'']]]
];

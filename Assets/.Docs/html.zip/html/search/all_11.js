var searchData=
[
  ['w',['w',['../struct_annotation_1_1_annotation_box.html#a8351fba84fd574b466abdc8922444524',1,'Annotation::AnnotationBox']]],
  ['webaddress',['webAddress',['../class_annotation.html#adb6d8fefb4974f1ff1d0f0a031455f37',1,'Annotation.webAddress()'],['../class_i_i_i_f_image_get.html#a4b3539da1bc9765bae28166cbe13bdfb',1,'IIIFImageGet.webAddress()']]],
  ['worldlight',['worldLight',['../class_move_spotlight.html#aa255c740ef3a0745b43b027e007bcb62',1,'MoveSpotlight']]]
];

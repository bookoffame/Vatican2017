var searchData=
[
  ['getaddress',['getAddress',['../class_i_i_i_f_image_get.html#af37d0e78a9db92c63e1f04e3589f05b1',1,'IIIFImageGet']]],
  ['getannotations',['GetAnnotations',['../class_annotation.html#a6f51b2747ec2eae72f61bd83fd9d47a7',1,'Annotation.GetAnnotations()'],['../class_page_images.html#af563e42dd7774f6ea7a51a9e5668ddc0',1,'PageImages.GetAnnotations()']]],
  ['getnumofpages',['getNumOfPages',['../class_assembly_c_sharp_1_1_i_i_i_f_get_manifest.html#a36f4b3870d7e913b9181b97b2e384707',1,'AssemblyCSharp::IIIFGetManifest']]],
  ['getpage',['getPage',['../class_assembly_c_sharp_1_1_i_i_i_f_get_manifest.html#a363267d41e370600e961c276a620eb31',1,'AssemblyCSharp::IIIFGetManifest']]],
  ['getpopuptext',['getPopupText',['../class_button_controls.html#af54ecb5ed2899a6a9302431f8df94833',1,'ButtonControls']]],
  ['getprogress',['GetProgress',['../class_i_i_i_f_image_get.html#af36dc447c2e08becce3eb0946b7372ec',1,'IIIFImageGet']]],
  ['getselected',['getSelected',['../class_button_controls.html#a1610d1a14723fdf450ded1e8818ce425',1,'ButtonControls']]],
  ['gettext',['getText',['../class_pop_up_box.html#ac80e75be1581aeacb6727bac277b5e1c',1,'PopUpBox']]]
];

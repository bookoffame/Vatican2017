var searchData=
[
  ['turnpageleft',['TurnPageLeft',['../class_page_images.html#a2d94ed5b60c041dd4550f4dfbca0ef94',1,'PageImages']]],
  ['turnpageright',['TurnPageRight',['../class_page_images.html#a290f753eca727781c135ce41e6fcd48a',1,'PageImages']]]
];

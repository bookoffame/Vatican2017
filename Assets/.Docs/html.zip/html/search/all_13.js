var searchData=
[
  ['y',['y',['../struct_annotation_1_1_annotation_box.html#abe016787ca879c554211b47dfc6b7965',1,'Annotation::AnnotationBox']]]
];

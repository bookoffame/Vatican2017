var searchData=
[
  ['x',['x',['../struct_annotation_1_1_annotation_box.html#a6e431b3be4693eec2a05836305c951b7',1,'Annotation::AnnotationBox']]]
];

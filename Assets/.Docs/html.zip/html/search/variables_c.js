var searchData=
[
  ['reader_5ftool',['READER_TOOL',['../class_button_controls.html#a45bd648b6f9269a063939e3e5ce487a0',1,'ButtonControls']]],
  ['righttrans',['rightTrans',['../class_page_images.html#a43dd571101b0554c29a48c8fab263042',1,'PageImages']]],
  ['rotation',['rotation',['../class_i_i_i_f_image_get.html#a4cdbf0a334d0be4334c00a2cb6eb26c1',1,'IIIFImageGet']]]
];

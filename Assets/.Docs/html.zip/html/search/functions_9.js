var searchData=
[
  ['removetail',['removeTail',['../class_i_i_i_f_image_get.html#aabc551661bd940d1a06c99074d3cd759',1,'IIIFImageGet']]],
  ['reset',['reset',['../class_pop_up_box.html#acc42337540e97fd45d2f5e6ed8451a4c',1,'PopUpBox']]]
];

var searchData=
[
  ['freezeposition',['freezePosition',['../class_move_spotlight.html#a46b925b55f919f6e86eaa22710d106c1',1,'MoveSpotlight']]]
];

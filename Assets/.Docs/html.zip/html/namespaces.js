var namespaces =
[
    [ "AssemblyCSharp", "namespace_assembly_c_sharp.html", null ]
];